<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class users extends Controller
{
    //
	
	function getEMdata($name){
		$return=array();
		$return["emname"]=$name;
		$return["emno"]=123456;
		return json_encode($return);
	}
	
	function index(Request $req){
		$data = $req->json()->all();
		return $this->getEMdata($data['username']);
	}
}
