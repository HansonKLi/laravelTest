<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class profile extends Controller
{
    //
	
	function index(Request $req, $name){
 
        return view('profile', ['name' => $name]);

    }
    
    function error405(Request $req){

        return response('{"errMsg":"no name of parameter on request."}', 405)
                ->header('Content-Type', 'text/json');
               
    }
    
    function fromPost(Request $req){
        $data = $req->json()->all();
        return response('{"name":"'.$data['username'].'","code":"'.md5('test').'", "created" : true}', 200)
                ->header('Content-Type', 'text/json');

    }

}
