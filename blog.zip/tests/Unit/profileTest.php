<?php


use Tests\TestCase;

class profileTest extends TestCase
{
    /**
     * A basic unit test example.
     *
     * @return void
     */

    // test variable of username is Hanson, using GET method to send it.
    public function testProfileWithName(){
       $response = $this->get('profile/Hanson');
       $response->assertStatus(200);
    }

    //test no any variables, using GET method to visit it.
    public function testProfileWithoutName(){
        $response = $this->get('profile');
        $response->assertStatus(405);
     }

    // test variable of username is Hanson, and the data structrue is Json, using POST method to send it.
     public function testProfileWithJson(){
        $response = $this->json('POST', 'profile', ['username' => 'Hanson']);
        // check response code is 200 and created of variable in ojbect is true which is boolean.
        $response
            ->assertStatus(200)
            ->assertJson([
                'created' => true,
            ]);
     }
}
