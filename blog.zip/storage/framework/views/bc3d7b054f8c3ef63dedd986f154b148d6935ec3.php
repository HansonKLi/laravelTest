Please send the data of Jason format to this page.
<?php /**PATH C:\xampp\htdocs\blog\resources\views/users.blade.php ENDPATH**/ ?>