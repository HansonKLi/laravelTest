<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::view('users','users');
Route::post('users','Users@index');
Route::get('user/{id}/{pwd}', function ($id,$pwd) {
    return 'User '.$id.' / Pwd '.$pwd;
});

/*
Route::get('profile/{name}', function ($name) {
    return view('profile', ['name' => $name]);
});
*/

Route::get('profile','Profile@error405');
Route::get('profile/{name}','Profile@index');
Route::post('profile','profile@fromPost');

